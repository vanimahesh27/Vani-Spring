package com.kumaran.first.app;


import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//spring should know this is the controller

@RestController
public class EmpController {

	@RequestMapping(name="/emp",method=RequestMethod.GET)
	public Employee getEmployee(@RequestParam Long id)
	{
		return new Employee(id,"Varun","CSE");
	}
	@RequestMapping(name="/emp" ,method=RequestMethod.POST,consumes="application/json")
	public Employee createEmployee(@RequestBody Employee emp)
	{
		return emp;
	}
}
